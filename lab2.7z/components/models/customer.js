

export default class Customer {
        constructor(name, salary, age) {
        this.name = name;
        this.salary = salary;
        this.age = age
    }


}